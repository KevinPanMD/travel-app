//
//  TravelPlanEditorView.swift
//  TravelPlanner
//
//  Created by Dingwen Wang on 2023/4/14.
//

import Foundation
import SwiftUI
import GoogleMaps

struct Activity: Identifiable, Codable {
    var id = UUID()
    let place: String
    let duration: TimeInterval
    let transportation: Transportation
}

enum Transportation: String, CaseIterable, Identifiable, Codable {
    case walking
    case cycling
    case driving
    case publicTransit = "public transit"

    var id: String { self.rawValue }
}

struct TravelPlanEditorView: View {
    @Binding var planId: UUID
    @Binding var startDate: Date
    @Binding var endDate: Date
    @State private var days: [[Activity]] = [[]]
    @State private var selectedDay = 0
    @State private var showingAddActivityView = false
    @State private var formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }()
    private var dateText: [String] = []
    

    private var numberOfDays: Int {
        let calendar = Calendar.current
        let startOfDay1 = calendar.startOfDay(for: startDate)
        let startOfDay2 = calendar.startOfDay(for: endDate)
        let daysBetween = calendar.dateComponents([.day], from: startOfDay1, to: startOfDay2).day ?? 0
        return daysBetween + 1
    }

    init(planId: Binding<UUID>, startDate: Binding<Date>, endDate: Binding<Date>) {
        self._planId = planId
        self._startDate = startDate
        self._endDate = endDate
        self._days = State(initialValue: Array(repeating: [], count: numberOfDays))
        print("Init \(planId)")
        loadDays()
        
        for index in 0..<numberOfDays {
            let date = Calendar.current.date(byAdding: .day, value: index, to: startDate.wrappedValue)!
            let dateString = formatter.string(from: date)
            dateText.append(dateString)
        }
    }

    var body: some View {
        VStack {
            Text("\(planId)")
            Picker("Day", selection: $selectedDay) {
                ForEach(0..<numberOfDays) { index in
                    Text(dateText[index])
                }
            }
            .pickerStyle(NavigationLinkPickerStyle())
            .padding()

            List {
                ForEach(days[selectedDay]) { activity in
                    VStack(alignment: .leading) {
                        Text(activity.place)
                            .font(.headline)
                        HStack {
                            Text("Duration: \(timeFormatter.string(from: activity.duration) ?? "Unknown duration")")

                            Text("Transportation: \(activity.transportation.rawValue.capitalized)")
                        }
                    }
                }
                .onDelete(perform: deleteActivity)
            }

            Button("Add Activity") {
                showingAddActivityView = true
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
            .sheet(isPresented: $showingAddActivityView) {
                AddActivityView { place, duration, transportation in
                    let newActivity = Activity(place: place, duration: duration, transportation: transportation)
                    days[selectedDay].append(newActivity)
                    saveDays()
                    showingAddActivityView = false
                }
            }
        }
        .navigationTitle("Travel Plan Editor")
        .onAppear {
            loadDays()
        }
        .onDisappear {
            saveDays()
        }
    }

    private func deleteActivity(at offsets: IndexSet) {
        days[selectedDay].remove(atOffsets: offsets)
        saveDays()
    }
    
    private func saveDays() {
        print("Save Days")
        UserDefaults.standard.set(try? PropertyListEncoder().encode(days), forKey: "\(planId.uuidString)")
    }
    
    private func loadDays() {
        print("Load Days")
        if let data = UserDefaults.standard.value(forKey: "\(planId.uuidString)") as? Data {
            if let savedDays = try? PropertyListDecoder().decode([[Activity]].self, from: data) {
                days = savedDays
                print("Load Success")
            }
        } else {
            days = Array(repeating: [], count: numberOfDays)
        }
    }
}

private let timeFormatter: DateComponentsFormatter = {
    let formatter = DateComponentsFormatter()
    formatter.allowedUnits = [.hour, .minute]
    formatter.unitsStyle = .abbreviated
    return formatter
}()

struct TravelPlanEditorView_Previews: PreviewProvider {
    static var previews: some View {
        TravelPlanEditorView(
            planId: .constant(UUID()),
            startDate: .constant(Date()),
            endDate: .constant(Calendar.current.date(byAdding: .day, value: 5, to: Date())!)
        )
    }
}

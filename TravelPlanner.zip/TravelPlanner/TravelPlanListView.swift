//
//  TravelPlanListView.swift
//  TravelPlanner
//
//  Created by Dingwen Wang on 2023/4/14.
//

import Foundation
import SwiftUI

struct TravelPlan: Identifiable, Codable {
    var id = UUID()
    let destination: String
    let startDate: Date
    let endDate: Date
}

struct TravelPlanListView: View {
    @State private var travelPlans: [TravelPlan] = []
    @State private var showingAddPlanView = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach(travelPlans) { plan in
                    NavigationLink(destination: TravelPlanEditorView(planId: Binding.constant(plan.id), startDate: Binding.constant(plan.startDate), endDate: Binding.constant(plan.endDate))) {
                        VStack(alignment: .leading) {
                            Text(plan.destination)
                                .font(.headline)
                            HStack {
                                Text("Start Date: \(plan.startDate, formatter: dateFormatter)")
                                Text("End Date: \(plan.endDate, formatter: dateFormatter)")
                            }
                        }
                    }
                }
                .onDelete(perform: deleteTravelPlan)
            }
            .navigationBarTitle("Travel Plans")
            .navigationBarItems(leading: EditButton(), trailing: addButton)
            .sheet(isPresented: $showingAddPlanView) {
                AddTravelPlanView { destination, startDate, endDate in
                    let newPlan = TravelPlan(destination: destination, startDate: startDate, endDate: endDate)
                    self.travelPlans.append(newPlan)
                    self.showingAddPlanView = false
                    saveTravelPlans()
                }
            }
        }.onAppear(perform: loadTravelPlans)
    }
    
    private var addButton: some View {
        Button(action: {
            showingAddPlanView = true
        }) {
            Image(systemName: "plus")
                .resizable()
                .frame(width: 22, height: 22)
                .foregroundColor(.blue)
        }
    }
    
    private func deleteTravelPlan(at offsets: IndexSet) {
        travelPlans.remove(atOffsets: offsets)
        saveTravelPlans()
    }
    
    private func saveTravelPlans() {
        if let encoded = try? JSONEncoder().encode(travelPlans) {
            UserDefaults.standard.set(encoded, forKey: "travelPlans")
        }
    }

    private func loadTravelPlans() {
        if let data = UserDefaults.standard.data(forKey: "travelPlans") {
            if let decoded = try? JSONDecoder().decode([TravelPlan].self, from: data) {
                travelPlans = decoded
            }
        }
    }

}

private let dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    return formatter
}()

struct TravelPlanListView_Previews: PreviewProvider {
    static var previews: some View {
        TravelPlanListView()
    }
}
